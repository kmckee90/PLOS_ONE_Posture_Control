
// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
double ipcDelay(NumericVector par, mat Z, int obj=1) {
  mat A, B, H, Q, R, P;
  colvec x, u;
  double
 pK=par[0],
 pB=par[1],
 pP=par[2],
 pD=par[3],
 delay=par[4],
 pQ=par[5],
 pR=par[6],
 
 pP0x=1, 
 pP0dx=1, 
          
 px0=par[7], 
 pdx0=par[8], 
 pd2x0=par[9],
            
 dt= Z(1,0)-Z(0,0), 
 lagN_ind=delay/dt;
  unsigned int  q = 2, lagN_low=delay/dt;
  double invalid = R_PosInf;
  

  if(pQ<0) return invalid;
  if(pR<0) return invalid;
  if(delay < 0) return invalid;
  
  //Delay diff Eq Transition matrix
  A.zeros(q,q);
  A(0,1)=1;
  A(1,0)=pK;
  A(1,1)=pB;
  
  Q.zeros(q,q);
  Q(1,1)=pQ;
  
  B.zeros(q,q);
  B(1,0)=pP;
  B(1,1)=pD;
  
  H.zeros(1,q);
  H(0,0) = 1.0;
  R = pR*eye(1,1);
  
  x.zeros(q);
  x[0]=px0;
  x[1]=pdx0;
  
  P.zeros(q,q);
  P(0,0)=pP0x;
  P(1,1)=pP0dx;
  
  u.zeros(q);
  
  //Discretization
  Environment base("package:IPCmodel");
  Function kd = base["kalmanIntegrate"];
  
  List kdMats = kd(A, B, Q, dt);
  mat Act = kdMats["Ad"];
  mat Qct = kdMats["Qd"];
  mat Bct = kdMats["Bd"];
  
  
  unsigned int n = Z.n_rows;
  mat Y = zeros(n+1, q), xprd, Pprd, S, kalmangain, Sinv, L; //Bct, Act, Qct;
  colvec y, m2ll = zeros(n);
  rowvec uT;
  double sign, Sdet, lagN_dif = lagN_ind - lagN_low, z, t=0;
  
  for (unsigned int i = 0; i<n; i++) {
    z = Z(i,1);

	t = t+dt;
	
	//Here, get u at t+dt.
	if(i <= lagN_ind){
	  u[0] = px0+pdx0*(t-delay)+pd2x0*pow(t-delay,2.0); 
	  u[1] = pdx0 + 2.0*pd2x0*(t-delay);
	}
	
    if(i > lagN_ind){
     uT = Y.row(i-lagN_low) + ( Y.row(i-lagN_low-1) - Y.row(i-lagN_low) )*lagN_dif; 
	 u = uT.t();
	}
	
	xprd = Act * x + Bct * u;
	Pprd = Act * P * Act.t() +  Bct  * P * Bct.t() + Qct;
	
    // estimation
    S = H * Pprd.t() * H.t() + R;
    L = H * Pprd.t();
    Sinv = inv(S);
    kalmangain = (Sinv*L).t();
    
    // estimated state and covariance
    x = xprd + kalmangain * (z - (H * xprd) );
    P = Pprd - kalmangain * H * Pprd;
    Y.row(i+1) = x.t();
    
	//Cost function
    log_det(Sdet, sign, S);
    m2ll.row(i) = Sdet + (z - H * xprd).t() * Sinv * (z - H * xprd) + log(2*M_PI) ;
  }
  if(is_finite(sum(m2ll))){ return sum(m2ll); }
  else {  return invalid; }
}

