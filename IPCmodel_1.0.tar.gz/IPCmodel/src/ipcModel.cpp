
// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
double ipcModel(NumericVector par, mat Z, int obj=1) {
  mat A, B, H, Q, R, P;
  colvec x, u, uNext;
  double
 pK=par[0],
 pB=par[1],
 pP=par[2],
 pD=par[3],
 pA=par[4],
 pRad=par[5],
 delay=par[6],
 pQ=par[7],
 pR=par[8],
 
 pP0x=1, //par[9],
 pP0dx=1, //par[10],
          
 px0=par[9], //par[11],
 pdx0=par[10], //par[12],
 pd2x0=par[11],
            
 dt= Z(1,0)-Z(0,0), dt2,
 lagN_ind=delay/dt;
  unsigned int  q = 2, lagN_low=delay/dt;
  double invalid = R_PosInf;
  
//  if(pK<0) return invalid;
//  if(pP>0) return invalid;
  if(pQ<0) return invalid;
  if(pR<0) return invalid;
  // if(pP0x<0) return invalid;
  // if(pP0dx<0) return invalid;
  if(delay < 0) return invalid;
  
  //Delay diff Eq Transition matrix
  A.zeros(q,q);
  A(0,1)=1;
  A(1,0)=pK;
  A(1,1)=pB;
  
  Q.zeros(q,q);
  Q(1,1)=pQ;
  
  B.zeros(q,q);
  B(1,0)=pP;
  B(1,1)=pD;
  
  H.zeros(1,q);
  H(0,0) = 1.0;
  R = pR*eye(1,1);
  
  x.zeros(q);
  x[0]=px0;	
  x[1]=pdx0;
  
  P.zeros(q,q);
  P(0,0)=pP0x;
  P(1,1)=pP0dx;
  
  u.zeros(q);
  uNext.zeros(q);
  
  //Discretization
  Environment base("package:IPCmodel");
  Function kd = base["kalmanIntegrate"];
  
  List kdMats = kd(A, B, Q, dt);
  mat Act0 = kdMats["Ad"];
  mat Qct0 = kdMats["Qd"];
  mat Bct0 = kdMats["Bd"];
  
  mat Act = Act0;
  mat Qct = Qct0;
  mat Bct = Bct0;
  
  
  unsigned int n = Z.n_rows;
  mat Y = zeros(n+1, q), xprd, Pprd, S, kalmangain, Sinv, L; //Bct, Act, Qct;
  colvec y, m2ll = zeros(n), uI, p1, p2;
  rowvec uT, uNextT;
  double sign, Sdet, lagN_dif = lagN_ind - lagN_low, ON, z, t=0, m, p1L, p2L, xI, yI;
  uI.zeros(2);
  
  for (unsigned int i = 0; i<n; i++) {
    z = Z(i,1);
	
	if(i>0){dt = Z(i,0)-Z(i-1,0);}
	
	t = t+dt;
	
	//Here, get u at t+dt.
	if(i <= lagN_ind){
	  u[0] = px0+pdx0*(t-delay)+pd2x0*pow(t-delay,2.0); 
	  u[1] = pdx0 + 2.0*pd2x0*(t-delay);
	  uNext[0] = px0+pdx0*(t-delay+dt)+pd2x0*pow(t-delay+dt,2.0); 
	  uNext[1] = pdx0 + 2.0*pd2x0*(t-delay+dt);
	}
	
    if(i > lagN_ind){
     uT = Y.row(i-lagN_low) + ( Y.row(i-lagN_low-1) - Y.row(i-lagN_low) )*lagN_dif; 
	 u = uT.t();
	 uNextT = Y.row(i-lagN_low+1) + ( Y.row(i-lagN_low) - Y.row(i-lagN_low+1) )*lagN_dif;
	 uNext = uNextT.t();
	}
	
	//Primary conditions
	if( u[0]*(u[1] - pA*u[0]) > 0.0 && ( pow(u[0],2.0) + pow(u[1],2.0) ) > pow(pRad, 2.0) ) {ON = 1.0;}  else {ON = 0.0;}
	
	
	//TURNING OFF
	if( ((u[0]*(u[1] - pA*u[0]) > 0.0) && ( pow(u[0],2.0) + pow(u[1],2.0) ) > pow(pRad, 2.0) ) && ((uNext[0]*(uNext[1] - pA*uNext[0]) <= 0.0) || (uNext[0]*uNext[0]+uNext[1]*uNext[1] <= pow(pRad, 2.0))) ){
		//Rcout<<"TURN OFF\n";
		//calculate dt to reach threshold
		if( pow(uNext[0],2.0) + pow(uNext[1],2.0)  > pow(pRad, 2.0) && !( (uNext[0] > 0 && uNext[1] < 0 &&   u[0] < 0 &&  u[1] < 0 ) || (uNext[0] < 0 && uNext[1] > 0 && u[0] > 0 && u[1] > 0)) ){
			m=(uNext[1]-u[1])/(uNext[0]-u[0]);
			xI=(-m*uNext[0]+uNext[1])/(pA-m);
			yI=m*xI-m*uNext[0]+uNext[1];
			uI[0]=xI; uI[1]=yI;
			p1= u-uI;
			p1L= as_scalar(sqrt(p1.t()*p1));
			p2= uNext-uI;
			p2L=as_scalar(sqrt(p2.t()*p2));
			ON=p1L/(p1L+p2L);	
		}	
		else if( pow(uNext[0],2.0) + pow(uNext[1],2.0)  < pow(pRad, 2.0) ){
			m=(uNext[1]-u[1])/(uNext[0]-u[0]);
			xI=(pRad*pRad + uNext[0]*uNext[0] + 2*m*uNext[0]*uNext[1]-uNext[1]*uNext[1])/(2*(uNext[0]+m*uNext[1]));
			yI=m*xI-m*uNext[0]+uNext[1];
			uI[0]=xI; uI[1]=yI;
			p1= u-uI;
			p1L= as_scalar(sqrt(p1.t()*p1));
			p2= uNext-uI;
			p2L=as_scalar(sqrt(p2.t()*p2));
			ON=p1L/(p1L+p2L);	
		}else{
			m=(uNext[1]-u[1])/(uNext[0]-u[0]);
			xI=0;
			yI=-m*uNext[0]+uNext[1];
			uI[0]=xI; uI[1]=yI;
			p1= u-uI;
			p1L= as_scalar(sqrt(p1.t()*p1));
			p2= uNext-uI;
			p2L=as_scalar(sqrt(p2.t()*p2));
			ON=p1L/(p1L+p2L);	
		}
		
		//Predict only up to threshold at ON*dt
		dt2=ON*dt;
		kdMats = kd(A, B, Q, dt2 );  
		Act = as<mat>(kdMats["Ad"]);
		Qct = as<mat>(kdMats["Qd"]);  
		Bct = as<mat>(kdMats["Bd"]);
		
		xprd = Act * x + Bct * u;
		Pprd = Act * P * Act.t() + Bct  * P * Bct.t() + Qct;
  
		//Predict from threshold to next observation
		dt2=(1-ON)*dt;
		kdMats = kd(A, B, Q, dt2);  
		Act = as<mat>(kdMats["Ad"]);
		Qct = as<mat>(kdMats["Qd"]);  
		Bct = as<mat>(kdMats["Bd"]);

		xprd = Act * xprd;
		Pprd = Act * Pprd * Act.t() + Qct;
		
		//Reset matrices for typical behavior
		Act = Act0;
		Qct = Qct0;
		Bct = Bct0;	
	}
	//TURNING ON
	else if( ((u[0]*(u[1] - pA*u[0]) <= 0.0) || ( pow(u[0],2.0) + pow(u[1],2.0) ) <= pow(pRad, 2.0) ) && ((uNext[0]*(uNext[1] - pA*uNext[0]) > 0.0) && (uNext[0]*uNext[0]+uNext[1]*uNext[1] > pow(pRad, 2.0))) ){
		//Rcout<<"TURN ON\n";
		//calculate dt to reach threshold
		if( pow(u[0],2.0) + pow(u[1],2.0)  > pow(pRad, 2.0) && !( (u[0] > 0 && u[1] < 0 && uNext[0] < 0 && uNext[1] < 0 ) || (u[0] < 0 && u[1] > 0 && uNext[0] > 0 && uNext[1] > 0)) ){
			m=(uNext[1]-u[1])/(uNext[0]-u[0]);
			xI=(-m*uNext[0]+uNext[1])/(pA-m);
			yI=m*xI-m*uNext[0]+uNext[1];
			uI[0]=xI; uI[1]=yI;
			p1= u-uI;
			p1L= as_scalar(sqrt(p1.t()*p1));
			p2= uNext-uI;
			p2L=as_scalar(sqrt(p2.t()*p2));
			ON=p1L/(p1L+p2L);	
		}	
		else if( pow(u[0],2.0) + pow(u[1],2.0) < pow(pRad, 2.0) ){
			m=(uNext[1]-u[1])/(uNext[0]-u[0]);
			xI=(pRad*pRad + uNext[0]*uNext[0] + 2*m*uNext[0]*uNext[1]-uNext[1]*uNext[1])/(2*(uNext[0]+m*uNext[1]));
			yI=m*xI-m*uNext[0]+uNext[1];
			uI[0]=xI; uI[1]=yI;
			p1= u-uI;
			p1L= as_scalar(sqrt(p1.t()*p1));
			p2= uNext-uI;
			p2L=as_scalar(sqrt(p2.t()*p2));
			ON=p1L/(p1L+p2L);
		}else{
			m=(uNext[1]-u[1])/(uNext[0]-u[0]);
			xI=0;
			yI=-m*uNext[0]+uNext[1];
			uI[0]=xI; uI[1]=yI;
			p1= u-uI;
			p1L= as_scalar(sqrt(p1.t()*p1));
			p2= uNext-uI;
			p2L=as_scalar(sqrt(p2.t()*p2));
			ON=p1L/(p1L+p2L);	
		}
		//Predict only up to threshold at ON*dt
		dt2=ON*dt;
		kdMats = kd(A, B, Q, dt2);  
		Act = as<mat>(kdMats["Ad"]);
		Qct = as<mat>(kdMats["Qd"]);  
		Bct = as<mat>(kdMats["Bd"]);
				
		xprd = Act * x;
		Pprd = Act * P * Act.t() + Qct;
		
		//Predict from threshold to next observation
		dt2=(1-ON)*dt;
		kdMats = kd(A, B, Q, dt2);  
		Act = as<mat>(kdMats["Ad"]);
		Qct = as<mat>(kdMats["Qd"]);  
		Bct = as<mat>(kdMats["Bd"]);

  		xprd = Act * xprd + Bct * uI;
		Pprd = Act * Pprd * Act.t() + Bct  * Pprd * Bct.t() + Qct;
		
		//Reset matrices for typical behavior
		Act = Act0;
		Qct = Qct0;
		Bct = Bct0;
	}else{
		xprd = Act * x + ON * Bct * u;
		Pprd = Act * P * Act.t() + ON * Bct  * P * Bct.t() + Qct;
    }
	
	
    // estimation
    S = H * Pprd.t() * H.t() + R;
    L = H * Pprd.t();
    Sinv = inv(S);
    kalmangain = (Sinv*L).t();
    
    // estimated state and covariance
    x = xprd + kalmangain * (z - (H * xprd) );
    P = Pprd - kalmangain * H * Pprd;
    Y.row(i+1) = x.t();
    
	//Cost function
	if(obj==1){
    log_det(Sdet, sign, S);
    m2ll.row(i) = Sdet + (z - H * xprd).t() * Sinv * (z - H * xprd) + log(2*M_PI) ;
     }else{
	m2ll.row(i) = (z - H * xprd).t() * Sinv * (z - H * xprd);	 
	 }

  }
  if(is_finite(sum(m2ll))){ return sum(m2ll); }
  else {  return invalid; }
}

