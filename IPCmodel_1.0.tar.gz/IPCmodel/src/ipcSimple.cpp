
// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;

// [[Rcpp::export]]
double ipcSimple(NumericVector par, mat Z) {
  mat A, B, H, Q, R, P;
  colvec x;
  double
 pK=par[0],
 pB=par[1],
 pQ=par[2],
 pR=par[3],
 
 pP0x=1, 
 pP0dx=1,
          
 px0=par[4], 
 pdx0=par[5], 
            
 dt= Z(1,0)-Z(0,0);

  unsigned int  q = 2;
  double invalid = R_PosInf;
  
  if(pQ<0) return invalid;
  if(pR<0) return invalid;
  
  A.zeros(q,q);
  A(0,1)=1;
  A(1,0)=pK;
  A(1,1)=pB;
  
  Q.zeros(q,q);
  Q(1,1)=pQ;
  
  B.zeros(q,q);
  
  H.zeros(1,q);
  H(0,0) = 1.0;
  
  R = pR*eye(1,1);
  
  x.zeros(q);
  x[0]=px0;
  x[1]=pdx0;
  
  P.zeros(q,q);
  P(0,0)=pP0x;
  P(1,1)=pP0dx;
  
  //Discretization
  Environment base("package:IPCmodel");
  Function kd = base["kalmanIntegrate"];
  
  List kdMats = kd(A, B, Q, dt);
  mat Act = kdMats["Ad"];
  mat Qct = kdMats["Qd"];
  //mat Bct = kdMats["Bd"];
  
  unsigned int n = Z.n_rows;
  mat xprd, pprd, S, kalmangain, Sinv, L;
  colvec z, y, m2ll = zeros(n);
  double sign, Sdet;
  
  for (unsigned int i = 0; i<n; i++) {
    z = Z(i,1);
    
   // predicted state and covariance
    xprd = Act * x;
    pprd = Act * P * Act.t() + Qct;
	
    // estimation
    S = H * pprd.t() * H.t() + R;
    L = H * pprd.t();
    Sinv = inv(S);
    kalmangain = (Sinv*L).t();
    
    // estimated state and covariance
    x = xprd + kalmangain * (z - H * xprd);
    P = pprd - kalmangain * H * pprd;
    
    log_det(Sdet, sign, S);
    m2ll.row(i) = Sdet + (z - H * xprd).t() * Sinv * (z - H * xprd) + log(2*M_PI) ;
  }
  if(is_finite(sum(m2ll))){ return sum(m2ll); }
  else {  return invalid; }
}

