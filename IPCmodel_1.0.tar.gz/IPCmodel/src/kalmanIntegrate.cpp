
// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
List kalmanIntegrate(mat A, mat B, mat Q, double dt) {
	mat M, expA, intA, Ad, Bd, Qd, I;
	List output;
	I.eye(A.n_rows, A.n_cols);
	M.zeros(2*A.n_rows, 2*A.n_cols);
	
	// First Block expm for A integral, and expm(A*deltaT)
	M.submat(0,  A.n_rows, A.n_rows-1, 2*A.n_rows-1) = I;
	M.submat(A.n_rows,  A.n_rows, 2*A.n_rows-1, 2*A.n_rows-1) = A;
	M=expmat(M*dt);
	
	intA = M.submat(0,  A.n_rows, A.n_rows-1, 2*A.n_rows-1);
	expA = M.submat(A.n_rows,  A.n_rows, 2*A.n_rows-1, 2*A.n_rows-1);
	
	// Second Block expm for discretized Q
	M.submat(0,  0, A.n_rows-1, A.n_rows-1) = -1*A.t();
	M.submat(A.n_rows,  0, 2*A.n_rows-1, A.n_rows-1) = zeros(A.n_rows, A.n_cols);
	M.submat(0,  A.n_rows, A.n_rows-1, 2*A.n_rows-1)=Q;
	M.submat(A.n_rows,  A.n_rows, 2*A.n_rows-1, 2*A.n_rows-1) = A;
	M=expmat(M*dt);
	
	output("Ad")=expA;
	output("Bd")=intA*B;
	output("Qd")=expA.t() * M.submat(0,  A.n_rows, A.n_rows-1, 2*A.n_rows-1);

	return output;
}
