
// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
mat ipcSimulate(NumericVector par, unsigned int seconds, double dt, unsigned int buffer = 500 ){
  unsigned int N = seconds/dt + buffer, q=2;
  mat A, B, ident, Y;
  double
    pK=par[0],
    pB=par[1],
    pP=par[2],
    pD=par[3],
    pA= cos(par[4]*M_PI)/sin(par[4]*M_PI),
    pRad=par[5],
    delay=par[6],
    pQ=par[7],
    lagN_ind=delay/dt,
    mgh = 9.81*60;
          
  unsigned int lagN_low=delay/dt;
  colvec x, u, Q, dWvec = sqrt(dt)*rnorm(N)*sqrt(pQ);
  
  A.zeros(q,q);
  A(0,1)=1;
  A(1,0)=(1-pK)*mgh / 60;
  A(1,1)= -pB/60;
  
  B.zeros(q,q);
  B(1,0)= -pP*mgh/60;
  B(1,1)= -pD/60;
  
  ident.eye(q,q);
  
  x.zeros(q);
  x[0]=1.0;
  u.zeros(q);
  Q.zeros(q);
  Y.zeros(N+1, q);
  
  mat Q0;
  Q0.zeros(q,q);
  Q0(q-1,q-1)=pQ;
  //Discretization
  Environment base("package:IPCmodel");
  Function kd = base["kalmanIntegrate"];
  
  List kdMats = kd(A, B, Q0, dt);
  mat Ad = kdMats["Ad"];
  mat Bd = kdMats["Bd"];

  double lagN_dif = lagN_ind - lagN_low, ON;
	rowvec uT;
	
  for (unsigned int i = 0; i<N; i++) {
    if(i > lagN_ind){
     uT = Y.row(i-lagN_low) + ( Y.row(i-lagN_low-1) - Y.row(i-lagN_low) )*lagN_dif; 
     u=uT.t();
	}
    if(i == lagN_ind){
      uT = Y.row(i-lagN_low); 
	  u=uT.t();
	}
    
    if( u[0]*(u[1] - pA*u[0]) > 0.0 && ( pow(u[0],2.0) + pow(u[1],2.0) ) > pow(pRad, 2.0) ) {
      ON=1.0;
    }  else {
      ON=0.0;
    }
    
    Q[1]=dWvec[i];
    x = Ad * x + ON * Bd * u + Q;
    Y.row(i+1)=x.t();
  }
  return Y.rows(buffer,N-1);
}
