


# Model -------------------------------------------------------------------
ipcMultiGroupScores<-function(par, Z, const){
  nPars<-12
  k<- ncol(Z)-1
  par.i<-par[1:nPars]
  
  par.i[1]<- (1-par[1])*prod(const)
  par.i[3]<- par[3]*prod(const)
  par.i[1:4]<- par.i[1:4]/60
  par.i[2:4]<- -par.i[2:4] 
  par.i[5]<- cos(par[5]*pi)/sin(par[5]*pi) #Convert 'alpha' to 'a', slope to percent active control
  
  origins<-matrix(par[(10+3*k):(9+4*k)],1,k)
  Z[,-1] <- Z[,-1] - (origins%x%matrix(1,nrow(Z)))
  
  scores<-NULL
  for(i in 2:(ncol(Z)) ){
    par.i[10:12]<-par[(10:12)+(i-2)*3] #Switch to new IVs for each new row.
    try( scores<-cbind(scores, ipcModelScores(par.i, Z[,c(1,i)])) )
  }
  return(scores)
}